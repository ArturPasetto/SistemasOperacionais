package jantarfilosofos;

import java.util.ArrayList;
import java.util.List;

public class JantarMain {
	
	public static void main(String[] args) {
		
		List<Hashi>hashis = new ArrayList<Hashi>();
		
		for (int i=0;i<5;i++){
			Hashi novohashi = new Hashi(i);
			hashis.add(i, novohashi);
		}
		
		for(int j=0;j<5;j++){
			Thread temp = new Thread( new Filosofo(hashis, j) );
			temp.setName("Fil�sofo "+j);
			temp.start();
		}

	}
	
}
