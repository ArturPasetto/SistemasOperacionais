package jantarfilosofos;

public class Hashi {

	private int idHashi;
	private boolean ocupado;
	private int dono;
	
	public Hashi(int id){
		this.idHashi = id;
		this.ocupado = false;
		this.dono = -1;
	}

	public int getIdHashi() {
		return idHashi;
	}

	public void setIdHashi(int idHashi) {
		this.idHashi = idHashi;
	}

	public boolean isOcupado() {
		return ocupado;
	}

	public void setOcupado(boolean ocupado) {
		this.ocupado = ocupado;
	}

	public int getDono() {
		return dono;
	}

	public void setDono(int dono) {
		this.dono = dono;
	}
	
	
	
}
