package jantarfilosofos;

import java.util.List;
import java.util.concurrent.Semaphore;

class Filosofo implements Runnable {
	
	public final int numerofilosofos = 5;
	public List<Hashi> hashis;
	public int filosofo;
	public static Semaphore semaforo = new Semaphore(1);
	
	Filosofo (List<Hashi> hashi, int fil){
		this.setHashis(hashi);
		this.setFilosofo(fil);
	}

	public void run(){
		pensar();
		try {
			semaforo.acquire();
			
			pegarHashi(this.getFilosofo(),this.getFilosofo());
			pegarHashi((this.getFilosofo()+1)%numerofilosofos, this.getFilosofo());
			comer(this.getFilosofo());
			largarHashi(this.getFilosofo(), this.getFilosofo());
			largarHashi((this.getFilosofo()+1)%numerofilosofos, this.getFilosofo());
			
			semaforo.release();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	private void pensar(){
		try{
			System.out.println("------- "+Thread.currentThread().getName()+" est� pensando -------");
			Thread.sleep(1000);
		}
		catch (InterruptedException e){
			System.out.println(e.getMessage());
		}
	}
	
	private void pegarHashi(int posicao, int novodono){
		if (hashis.get(posicao).isOcupado()==false){
			
			hashis.get(posicao).setOcupado(true);
			hashis.get(posicao).setDono(novodono);
			
			System.out.println("------- "+Thread.currentThread().getName()+" pegou o hashi "+posicao+" -------");
		}
	}
	
	private void largarHashi(int posicao, int dono){
		if (hashis.get(posicao).isOcupado()==true && 
				hashis.get(posicao).getDono() == dono){ 
			
			System.out.println("------- "+Thread.currentThread().getName()+" largou o hashi "+posicao+" -------");
			
			hashis.get(posicao).setOcupado(false);
			hashis.get(posicao).setDono(-1);
		}
	}
	
	private void comer(int filosofo){

		if (hashis.get(filosofo).isOcupado() &&
			hashis.get(filosofo).getDono()==filosofo &&
			hashis.get((filosofo+1)%numerofilosofos).isOcupado() &&	
			hashis.get((filosofo+1)%numerofilosofos).getDono()==filosofo){
			
			System.out.println("========= "+Thread.currentThread().getName()+" est� comendo =========");
			try{ 
				Thread.sleep(3000);
			}
			catch (InterruptedException e){
				System.out.println(e.getMessage());
			}
			
		}
	}

	
	public List<Hashi> getHashis() {
		return hashis;
	}

	public void setHashis(List<Hashi> hashis) {
		this.hashis = hashis;
	}

	public int getFilosofo() {
		return filosofo;
	}

	public void setFilosofo(int filosofo) {
		this.filosofo = filosofo;
	}
	
	
}