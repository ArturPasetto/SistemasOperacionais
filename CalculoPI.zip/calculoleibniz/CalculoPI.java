package calculoleibniz;

import java.util.concurrent.Semaphore;

public class CalculoPI implements Runnable {

	public static final int tamanhovetor=2048;
	public static int contador;
	public static double soma=1;
	public Semaphore semaforo = new Semaphore(1);
	
	public synchronized void subtracao(int n) {
		try {
			double valor = 1;
			valor/=(2*n)+1;
			
			semaforo.acquire();
			soma-=valor;
			semaforo.release();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public synchronized void soma(int n) {
			try {
				double valor = 1;
				valor/=(2*n)+1;
				
				semaforo.acquire();
				soma+=valor;
				semaforo.release();
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//System.out.println("Soma: \n"+soma);
	}
	
	public CalculoPI(int valor) {
		contador=valor;
	}
	
	public void run() {
		
		try {
			
			if(contador%2==0) {
				this.soma(contador);
			}
			else {
				this.subtracao(contador);
			}
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	
	public static void main(String[] args) {
		
		Thread th[] = new Thread[2];
	
		for(int i=1;i<=tamanhovetor;i++) {
			
			if(i%2==0) {
				th[0] = new Thread(new CalculoPI(i));
				th[0].start();
			}
			else {
				th[1] = new Thread(new CalculoPI(i));
				th[1].start();
			}
			
			try {
				th[1].join();
				th[0].join();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		
		}
		
		

		System.out.println("O Valor de PI � "+4*soma);
		
	}

	
}
